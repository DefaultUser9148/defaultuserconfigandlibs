package net.defaultuserconfigandlibs.screen;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * A reusable confirmation dialog screen with a title, multiple body lines,
 * and Yes/No buttons.
 *
 * Usage:
 *   client.setScreen(new ConfirmActionScreen(
 *       parent,
 *       Text.literal("Warning"),
 *       List.of("Line one", "Line two"),
 *       confirmed -> { if (confirmed) doThing(); }
 *   ));
 */
public class ConfirmActionScreen extends class_437 {

    private final class_437 parent;
    private final List<String> bodyLines;
    private final Consumer<Boolean> callback;

    public ConfirmActionScreen(class_437 parent, class_2561 title, List<String> bodyLines, Consumer<Boolean> callback) {
        super(title);
        this.parent = parent;
        this.bodyLines = bodyLines;
        this.callback = callback;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int buttonY = field_22790 / 2 + (bodyLines.size() * 10) + 20;

        method_37063(class_4185.method_46430(class_2561.method_43470("Yes"), btn -> {
            callback.accept(true);
            field_22787.method_1507(parent);
        }).method_46434(centerX - 102, buttonY, 100, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("No"), btn -> {
            callback.accept(false);
            field_22787.method_1507(parent);
        }).method_46434(centerX + 2, buttonY, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        // Title
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - (bodyLines.size() * 10) - 20, 0xFF5555);

        // Body lines
        int y = field_22790 / 2 - (bodyLines.size() * 10);
        for (String line : bodyLines) {
            context.method_27534(field_22793, class_2561.method_43470(line), field_22789 / 2, y, 0xFFFFFF);
            y += 12;
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25422() {
        return false;
    }
}
