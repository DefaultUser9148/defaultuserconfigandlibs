package net.defaultuserconfigandlibs.screen;

import net.defaultuserconfigandlibs.SimpleConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * A settings screen that displays boolean config entries as left-aligned toggles —
 * like raw HTML with no CSS: no centering, no frills.
 *
 * <p>Each entry occupies one row: [label at left] [ON/OFF button at fixed column].
 * Entries are stacked top-to-bottom starting from the top-left.
 *
 * <p>Changes are saved immediately when a toggle is clicked.
 */
public class ConfigEntryScreen extends class_437 {

    private static final int PAD         = 8;
    private static final int ROW_H       = 20;
    private static final int ROW_GAP     = 4;
    private static final int LABEL_COL   = PAD;
    private static final int TOGGLE_COL  = 240;
    private static final int TOGGLE_W    = 50;
    private static final int TOP_OFFSET  = 30; // below title line

    private final class_437 parent;
    private final SimpleConfig config;

    public ConfigEntryScreen(class_437 parent, String screenTitle, SimpleConfig config) {
        super(class_2561.method_43470(screenTitle));
        this.parent = parent;
        this.config = config;
    }

    @Override
    protected void method_25426() {
        int y = TOP_OFFSET;

        for (String key : config.keys()) {
            final String k = key;
            final int btnY = y;

            class_4185 toggle = class_4185.method_46430(
                class_2561.method_43470(config.getBoolean(k) ? "ON" : "OFF"),
                btn -> {
                    boolean next = !config.getBoolean(k);
                    config.setBoolean(k, next);
                    btn.method_25355(class_2561.method_43470(next ? "ON" : "OFF"));
                    config.save();
                }
            ).method_46434(TOGGLE_COL, btnY, TOGGLE_W, ROW_H).method_46431();

            method_37063(toggle);
            y += ROW_H + ROW_GAP;
        }

        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn ->
            field_22787.method_1507(parent)
        ).method_46434(PAD, field_22790 - PAD - ROW_H, 100, ROW_H).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);

        // Screen title
        ctx.method_27535(field_22793, field_22785, PAD, PAD, 0xFFFFFF);

        int y = TOP_OFFSET;
        for (String key : config.keys()) {
            // Vertically center label in the row
            ctx.method_27535(field_22793, class_2561.method_43470(key),
                LABEL_COL, y + (ROW_H - 8) / 2, 0xCCCCCC);
            y += ROW_H + ROW_GAP;
        }
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
