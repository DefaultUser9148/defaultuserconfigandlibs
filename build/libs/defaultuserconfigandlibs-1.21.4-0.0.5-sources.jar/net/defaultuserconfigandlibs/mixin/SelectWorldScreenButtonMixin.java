package net.defaultuserconfigandlibs.mixin;

import net.defaultuserconfigandlibs.WorldSelectButtonRegistry;
import net.minecraft.class_2561;
import net.minecraft.class_34;
import net.minecraft.class_4185;
import net.minecraft.class_526;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_526.class)
public class SelectWorldScreenButtonMixin {

    @Shadow private class_4185 selectButton;

    @Unique private class_2561 dlib_originalSelectLabel = null;

    @Inject(method = "init", at = @At("TAIL"))
    private void dlib_captureOriginalLabel(CallbackInfo ci) {
        if (this.selectButton != null) {
            dlib_originalSelectLabel = this.selectButton.method_25369();
        }
    }

    @Inject(method = "worldSelected", at = @At("TAIL"))
    private void dlib_onWorldSelected(class_34 level, CallbackInfo ci) {
        if (this.selectButton == null || level == null) return;

        String label   = WorldSelectButtonRegistry.resolveLabel(level);
        String tooltip = WorldSelectButtonRegistry.resolveTooltip(level);

        // Button label — override or restore vanilla default
        if (label != null) {
            this.selectButton.method_25355(class_2561.method_43470(label));
        } else if (dlib_originalSelectLabel != null) {
            this.selectButton.method_25355(dlib_originalSelectLabel);
        }

        // Tooltip — always clear first, then set if override exists
        this.selectButton.method_47400(null);
        if (tooltip != null) {
            this.selectButton.method_47400(class_7919.method_47407(class_2561.method_43470(tooltip)));
        }
    }
}
