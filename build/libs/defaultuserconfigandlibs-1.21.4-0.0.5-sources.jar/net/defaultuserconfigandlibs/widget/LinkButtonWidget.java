package net.defaultuserconfigandlibs.widget;

import net.defaultuserconfigandlibs.DefaultUserConfigAndLibs;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.net.URI;

/**
 * An IconButtonWidget that opens a URL when clicked.
 */
public class LinkButtonWidget extends IconButtonWidget {

    public LinkButtonWidget(int x, int y, int size, class_2960 texture, class_2561 tooltip, String url) {
        super(x, y, size, texture, tooltip, btn -> {
            try {
                class_156.method_668().method_673(new URI(url));
            } catch (Exception e) {
                DefaultUserConfigAndLibs.LOGGER.error("Failed to open link: {}", url, e);
            }
        });
    }
}
