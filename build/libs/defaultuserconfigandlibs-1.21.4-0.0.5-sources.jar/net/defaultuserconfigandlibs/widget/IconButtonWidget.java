package net.defaultuserconfigandlibs.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/**
 * A square button that renders a texture icon instead of text.
 * Size defaults to 20x20 to match vanilla button rows.
 */
public class IconButtonWidget extends class_4185 {

    protected final class_2960 texture;
    protected final int iconSize;

    public IconButtonWidget(int x, int y, int size, class_2960 texture, class_2561 tooltip, class_4241 onPress) {
        super(x, y, size, size, class_2561.method_43473(), onPress, field_40754);
        this.texture = texture;
        this.iconSize = size - 4; // 2px padding each side
        if (!tooltip.getString().isEmpty()) {
            method_47400(net.minecraft.class_7919.method_47407(tooltip));
        }
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        // Draw the standard button background
        super.method_48579(context, mouseX, mouseY, delta);
        // Draw the icon centered inside using drawGuiTexture (1.21.4 API)
        int iconX = method_46426() + (field_22758  - iconSize) / 2;
        int iconY = method_46427() + (field_22759 - iconSize) / 2;
        context.method_25290(net.minecraft.class_1921::method_62277, texture, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
    }
}
