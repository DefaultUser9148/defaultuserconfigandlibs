package net.defaultuserconfigandlibs.widget;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;

/**
 * Utility for creating and placing icon buttons on screens.
 *
 * createIconButton / createLinkButton — slot-based fixed placement.
 * findSmartX — scans existing widgets on a row and returns the next open X position.
 */
public class ModMenuButtonHelper {

    public static final int BUTTON_SIZE = 20;

    // Vanilla title screen row Y: height/4 + 156
    public static final int TITLE_ROW_Y_OFFSET_A = 4;   // divide height by this
    public static final int TITLE_ROW_Y_OFFSET_B = 156;  // then add this

    /**
     * Scans all children for ClickableWidgets on the given row Y (±2px tolerance)
     * and returns the X position just after the rightmost one.
     * Falls back to fallbackX if no widgets found on that row.
     */
    public static int findSmartX(List<? extends class_364> children, int rowY, int fallbackX) {
        int maxRight = fallbackX;
        for (class_364 child : children) {
            if (child instanceof class_339 cw) {
                if (Math.abs(cw.method_46427() - rowY) <= 2) {
                    int right = cw.method_46426() + cw.method_25368();
                    if (right > maxRight) {
                        maxRight = right;
                    }
                }
            }
        }
        return maxRight + 4;
    }

    /**
     * Creates a square icon button at a slot-based fixed X position.
     * x = screenWidth/2 + 106 + (slot * (BUTTON_SIZE + 2))
     */
    public static IconButtonWidget createIconButton(int screenWidth, int baseY, int slot,
                                                    class_2960 texture, class_2561 tooltip,
                                                    class_4185.class_4241 onPress) {
        int x = screenWidth / 2 + 106 + (slot * (BUTTON_SIZE + 2));
        return new IconButtonWidget(x, baseY, BUTTON_SIZE, texture, tooltip, onPress);
    }

    /**
     * Creates a link button at a slot-based fixed X position.
     */
    public static LinkButtonWidget createLinkButton(int screenWidth, int baseY, int slot,
                                                    class_2960 texture, class_2561 tooltip, String url) {
        int x = screenWidth / 2 + 106 + (slot * (BUTTON_SIZE + 2));
        return new LinkButtonWidget(x, baseY, BUTTON_SIZE, texture, tooltip, url);
    }
}
